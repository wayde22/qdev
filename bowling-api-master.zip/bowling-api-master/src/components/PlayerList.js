import React from 'react';

const PlayerList = ({}) => (
	<div className="PlayerList">
		<div>PlayerList</div>
	</div>
);

export default PlayerList;
